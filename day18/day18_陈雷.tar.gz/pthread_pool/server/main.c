#include "head.h"
#include "task_que.h"
#include "factory.h"
#include "tcp_init.h"
#include "epoll_op.h"

int main(int argc, char* argv[]){
	if(argc!=5){
		printf("command IP PORT THREADNUM TASKMAX\n");
		return -1;
	}
	int ret;
	//tcp
	int sfd;
	ret = serverTcpInit(&sfd, argv[1], (unsigned short)atoi(argv[2]));
	if(-1==ret){
		printf("serverTcpInit failed\n");
		return -1;
	}
	printf("serverTcpInit success\n");
	//factory
	Factory_t Factory;
	ret = factoryInit(&Factory, atoi(argv[3]), atoi(argv[4]));
	if(-1==ret){
		printf("factoryInit failed\n");
		return -1;
	}
	printf("factoryInit success\n");
	ret = factoryStart(&Factory);
	if(-1==ret){
		printf("factoryStart failed\n");
		return -1;
	}
	printf("factoryStart success\n");
	//epoll
	int epfd = epoll_create(1);
	epollAdd(epfd, sfd);
	struct epoll_event *events;
	events = (struct epoll_event*)calloc(1, sizeof(struct epoll_event));
	int readFdNum, i;
	//Task Queue
	pQue_t pTaskQue = &Factory.que;
	pNode_t pTaskNode;
	while(1){
		readFdNum = epoll_wait(epfd, events, 1, -1);
		for(i=0; i<readFdNum; i++){
			if(events[i].data.fd==sfd){
				pTaskNode = (pNode_t)calloc(1, sizeof(Node_t));
				pTaskNode->clientFd = accept(sfd, NULL, NULL);
				pthread_mutex_lock(&pTaskQue->mutex);
				ret = enQueue(pTaskQue, pTaskNode);
				pthread_mutex_unlock(&pTaskQue->mutex);
				pthread_cond_signal(&Factory.cond);
			}
		}
	}
	return 0;
}
