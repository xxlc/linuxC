#include "factory.h"
#include "task_que.h"
#include "transFile.h"

//传入参数：工厂指针，线程数目，最大任务数
int factoryInit(pFactory_t pFactory, int threadNum, int taskMax){
	queInit(&pFactory->que, taskMax);
	pthread_cond_init(&pFactory->cond, NULL);
	pFactory->pthid = (pthread_t*)calloc(threadNum, sizeof(pthread_t));
	pFactory->threadNum = threadNum;
	pFactory->startFlag = 0;
	return 0;
}


void clean(void* args){
	pthread_mutex_t *pMutex = (pthread_mutex_t*)args;
	pthread_mutex_unlock(pMutex);
}
void* pthreadFunc(void* args){
	pFactory_t pFactory = (pFactory_t)args;
	pthread_cond_t *pCond = &pFactory->cond;
	pQue_t pTaskQue = &pFactory->que;
	pthread_mutex_t *pMutex = &pTaskQue->mutex;
	pNode_t pTaskNode;
	int ret;
	while(1){
		pthread_mutex_lock(pMutex);
		printf("pthread wait\n");
		pthread_cond_wait(pCond, pMutex);
		printf("pthread wake\n");
		pthread_cleanup_push(clean, pMutex);
		ret = deQueue(pTaskQue, &pTaskNode);
		pthread_cleanup_pop(1);
		//任务开始
		if(-1==ret){
			printf("deQueue failed\n");
			continue;
		}
		printf("I am thread. I am working.\n");	
		sendFileByMmap(pTaskNode->clientFd, (char*)"file");
		//任务结束
	}
	pthread_exit(NULL);
}

//创建各子线程，将各个线程加入cond条件变量队列
int factoryStart(pFactory_t pFactory){
	for(int i=0; i<pFactory->threadNum; i++){
		pthread_create(pFactory->pthid+i, NULL, pthreadFunc, pFactory);
	}
	return 0;
} 
